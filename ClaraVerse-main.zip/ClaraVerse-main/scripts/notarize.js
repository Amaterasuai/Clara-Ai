// This script is no longer used as notarization is disabled
// It's kept here for reference in case notarization is needed in the future
exports.default = async function notarizing(context) {
  console.log('Notarization disabled - skipping process');
  return;
};
